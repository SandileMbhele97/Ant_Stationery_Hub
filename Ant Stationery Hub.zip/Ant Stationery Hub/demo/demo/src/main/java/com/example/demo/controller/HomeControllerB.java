package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class HomeControllerB {

	String appName;
	
	@GetMapping("/homes")
	public String homeP()
	{
		
		
		return "homes.html";
	}
	@GetMapping("/browser")
	public String homePh()
	{
		
		
		
		return "browser.html";
	}
	/*@GetMapping("/books")
	public String books()
	{
		
		
		
		return "books";
	}
	@GetMapping("/instrument")
	public String instrument()
	{
		
		
		
		return "instrument";
	}
	@GetMapping("/toys")
	public String toys()
	{
		
		
		
		return "toys";
	}*/
}
